package com.enums;

public enum Role {
    ADMIN,
   NORMAL
}
