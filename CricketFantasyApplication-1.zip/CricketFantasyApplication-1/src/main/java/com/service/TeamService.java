package com.service;

import com.model.Team;

public interface TeamService {

	public Team createTeam(Team team);
	  public void calculateTeamScores();
}
