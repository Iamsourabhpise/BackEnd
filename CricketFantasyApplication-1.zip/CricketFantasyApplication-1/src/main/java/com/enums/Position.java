package com.enums;

public enum Position {
	  BATSMAN,
	    BOWLER,
	    WICKET_KEEPER,
	    ALL_ROUNDER
}
